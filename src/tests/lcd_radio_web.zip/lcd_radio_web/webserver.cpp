/**
 * @file webserver.cpp
 * @brief Web server implementation for SI4703 radio control with WebSocket support
 * @details Provides web-based control interface with real-time WebSocket communication
 */

#include "webserver.h"
#include <WiFi.h>
#include <WiFiClient.h>
#include <WiFiServer.h>
#include <WebSocketsServer.h>
#include <ArduinoJson.h>

// Global objects
WiFiServer server(80);
WebSocketsServer webSocket = WebSocketsServer(81);

// Connection state
bool wifiConnected = false;
extern bool muteState; // Defined in radio_screen.cpp

// Callback function pointers
void (*cb_seekUp)() = nullptr;
void (*cb_seekDown)() = nullptr;
void (*cb_stepUp)() = nullptr;          // Manual step up
void (*cb_stepDown)() = nullptr;        // Manual step down
void (*cb_volumeUp)() = nullptr;
void (*cb_volumeDown)() = nullptr;
void (*cb_setFreq)(uint16_t) = nullptr;
uint16_t (*cb_getFreq)() = nullptr;
uint8_t (*cb_getVol)() = nullptr;
uint8_t (*cb_getRssi)() = nullptr;
void (*cb_setMute)(bool) = nullptr;
void (*cb_setVolume)(uint8_t) = nullptr;
void (*cb_recallMemory)(uint8_t) = nullptr;
void (*cb_storeMemory)(uint8_t) = nullptr;
uint16_t (*cb_getMemoryFreq)(uint8_t) = nullptr; // Get frequency from memory slot

/**
 * @brief WebSocket event handler
 */
void webSocketEvent(uint8_t num, WStype_t type, uint8_t * payload, size_t length) {
    switch(type) {
        case WStype_DISCONNECTED: {
            Serial.printf("[%u] Disconnected!\n", num);
            break;
        }
            
        case WStype_CONNECTED: {
            IPAddress ip = webSocket.remoteIP(num);
            Serial.printf("[%u] Connected from %d.%d.%d.%d url: %s\n", num, ip[0], ip[1], ip[2], ip[3], payload);
            
            // Send initial status to new client immediately
            delay(50); // Small delay to ensure connection is stable
            sendStatusToClient(num);
            break;
        }
            
        case WStype_TEXT: {
            Serial.printf("[%u] get Text: %s\n", num, payload);
            
            // Parse JSON command
            DynamicJsonDocument doc(1024);
            deserializeJson(doc, payload);
            
            String command = doc["command"];
            
            if (command == "seekUp" && cb_seekUp) {
                cb_seekUp();
            }
            else if (command == "seekDown" && cb_seekDown) {
                cb_seekDown();
            }
            else if (command == "stepUp" && cb_stepUp) {
                cb_stepUp();
            }
            else if (command == "stepDown" && cb_stepDown) {
                cb_stepDown();
            }
            else if (command == "volumeUp" && cb_volumeUp) {
                cb_volumeUp();
            }
            else if (command == "volumeDown" && cb_volumeDown) {
                cb_volumeDown();
            }
            else if (command == "setVolume" && cb_setVolume) {
                uint8_t volume = doc["volume"];
                cb_setVolume(volume);
            }
            else if (command == "toggleMute" && cb_setMute) {
                cb_setMute(!muteState);
            }
            else if (command == "recallMemory" && cb_recallMemory) {
                uint8_t memorySlot = doc["slot"];
                cb_recallMemory(memorySlot);
            }
            else if (command == "storeMemory" && cb_storeMemory) {
                uint8_t memorySlot = doc["slot"];
                cb_storeMemory(memorySlot);
            }
            else if (command == "getStatus") {
                // Just send current status - no action needed
            }
            
            // Send updated status to all clients
            broadcastRadioStatus();
            break;
        }
            
        default:
            break;
    }
}

/**
 * @brief Generate HTML page content
 */
String generateHTML() {
    String html = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SI4703 Radio Control</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f0f0f0;
        }
        .container {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 30px;
        }
        .status {
            background-color: #e8f4fd;
            border: 1px solid #bee5eb;
            border-radius: 6px;
            padding: 15px;
            margin-bottom: 20px;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
            box-sizing: border-box;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
        }
        .frequency-display {
            font-size: 48px;
            font-weight: bold;
            color: #2c5aa0;
            flex: 1;
            text-align: left;
        }
        .status-info {
            display: flex;
            flex-direction: column;
            gap: 6px;
            text-align: left;
            font-size: 14px;
            min-width: 150px;
        }
        .status-line {
            display: flex;
            justify-content: flex-start;
            align-items: center;
            gap: 8px;
        }
        .status-label {
            color: #666;
            font-weight: bold;
            font-size: 12px;
            min-width: 55px;
            text-transform: uppercase;
        }
        .status-value {
            color: #333;
            font-weight: normal;
            font-size: 12px;
        }
        .mute-status {
            color: #999;
            font-style: normal;
            font-size: 12px;
            text-transform: uppercase;
        }
        .mute-status.muted {
            color: #ff0000;
            font-weight: bold;
            font-style: normal;
            font-size: 12px;
            text-transform: uppercase;
        }
        .controls {
            display: grid;
            gap: 15px;
            margin-bottom: 20px;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }
        .control-group {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 15px;
            background-color: #fafafa;
            width: 100%;
            box-sizing: border-box;
        }
        .control-group h3 {
            margin: 0 0 15px 0;
            color: #333;
            font-size: 16px;
        }
        .btn-row {
            display: flex;
            gap: 10px;
            justify-content: center;
            flex-wrap: wrap;
            align-items: center;
        }
        .btn {
            background-color: #4CAF50;
            border: none;
            color: white;
            padding: 14px 22px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 18px;
            margin: 4px;
            cursor: pointer;
            border-radius: 6px;
            transition: background-color 0.3s;
            min-width: 85px;
            flex: 1;
            max-width: 120px;
        }
        .btn:hover {
            background-color: #45a049;
        }
        .btn:active {
            background-color: #3d8b40;
        }
        .btn.step {
            background-color: #2196F3;
        }
        .btn.step:hover {
            background-color: #1976D2;
        }
        .btn.seek {
            background-color: #FF9800;
        }
        .btn.seek:hover {
            background-color: #F57C00;
        }
        .btn.volume {
            background-color: #9C27B0;
        }
        .btn.volume:hover {
            background-color: #7B1FA2;
        }
        .btn.memory {
            background-color: #795548;
            min-width: 60px;
            height: 60px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: center;
            padding: 8px 12px;
            font-size: 14px;
            line-height: 1.2;
        }
        .btn.memory:hover {
            background-color: #5D4037;
        }
        .memory-label {
            font-weight: bold;
            font-size: 14px;
        }
        .memory-freq {
            font-size: 10px;
            opacity: 0.8;
            margin-top: 2px;
        }
        .btn.mute {
            background-color: #f44336;
        }
        .btn.mute:hover {
            background-color: #d32f2f;
        }
        .input-group {
            display: flex;
            gap: 10px;
            align-items: center;
            justify-content: center;
            margin: 15px 0;
        }
        .btn.memory.storing {
            background-color: #2196F3 !important;
            animation: pulse 0.5s ease-in-out;
        }
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
        .volume-control {
            display: flex;
            align-items: center;
            gap: 10px;
            justify-content: center;
            flex-wrap: wrap;
        }
        .volume-slider {
            flex: 1;
            min-width: 150px;
            max-width: 200px;
        }
        .info {
            text-align: center;
            color: #666;
            font-size: 14px;
            margin-top: 10px;
        }
        @media (max-width: 600px) {
            .controls, .status {
                max-width: 95%;
                margin-left: auto;
                margin-right: auto;
            }
            .status {
                flex-direction: column;
                text-align: center;
                gap: 15px;
            }
            .frequency-display {
                text-align: center;
                font-size: 36px;
            }
            .status-info {
                text-align: center;
                min-width: auto;
            }
            .status-line {
                justify-content: center;
            }
            .btn-row {
                flex-direction: column;
                align-items: stretch;
            }
            .btn {
                min-width: auto;
                max-width: none;
                flex: none;
            }
            .volume-control {
                flex-direction: column;
                gap: 15px;
            }
            .volume-slider {
                min-width: auto;
                max-width: none;
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>SI4703 FM Radio Control</h1>
        
        <div class="status">
            <div class="frequency-display" id="frequency">Loading...</div>
            <div class="status-info">
                <div class="status-line">
                    <span class="status-label">RSSI:</span>
                    <span class="status-value">-<span id="rssi">--</span> dBm</span>
                </div>
                <div class="status-line">
                    <span class="status-label">VOLUME:</span>
                    <span class="status-value"><span id="volume">--</span></span>
                </div>
                <div class="status-line">
                    <span class="status-label">STATUS:</span>
                    <span id="muteStatus" class="mute-status">NORMAL</span>
                </div>
            </div>
        </div>

        <div class="controls">
            <!-- Scan Controls -->
            <div class="control-group">
                <h3>Scan Controls</h3>
                <div class="btn-row">
                    <button class="btn seek" onmousedown="startSeek('seekDown')" onmouseup="stopAction()" onmouseleave="stopAction()">&lt;&lt;</button>
                    <button class="btn seek" onmousedown="startSeek('seekUp')" onmouseup="stopAction()" onmouseleave="stopAction()">&gt;&gt;</button>
                    <button class="btn step" onmousedown="startStep('stepDown')" onmouseup="stopStep()" onmouseleave="stopStep()">&lt;</button>
                    <button class="btn step" onmousedown="startStep('stepUp')" onmouseup="stopStep()" onmouseleave="stopStep()">&gt;</button>
                </div>
                <div class="info">&lt;&lt; &gt;&gt;: Auto-find stations | &lt; &gt;: Manual step (Hold 5s for fast step)</div>
            </div>

            <!-- Volume Controls -->
            <div class="control-group">
                <h3>Volume Control</h3>
                <div class="volume-control">
                    <button class="btn volume" onclick="sendCommand('volumeDown')">VOL-</button>
                    <input type="range" id="volumeSlider" class="volume-slider" min="0" max="100" value="50" onchange="setVolume(this.value)">
                    <button class="btn volume" onclick="sendCommand('volumeUp')">VOL+</button>
                    <button class="btn mute" onclick="sendCommand('toggleMute')" id="muteBtn">MUTE</button>
                </div>
            </div>

            <!-- Memory Presets -->
            <div class="control-group">
                <h3>Memory Presets</h3>
                <div class="btn-row">
                    <button class="btn memory" onmousedown="startMemory(1)" onmouseup="stopMemory()" onmouseleave="stopMemory()">
                        <span class="memory-label">M1</span>
                        <span class="memory-freq" id="mem1freq">---.-</span>
                    </button>
                    <button class="btn memory" onmousedown="startMemory(2)" onmouseup="stopMemory()" onmouseleave="stopMemory()">
                        <span class="memory-label">M2</span>
                        <span class="memory-freq" id="mem2freq">---.-</span>
                    </button>
                    <button class="btn memory" onmousedown="startMemory(3)" onmouseup="stopMemory()" onmouseleave="stopMemory()">
                        <span class="memory-label">M3</span>
                        <span class="memory-freq" id="mem3freq">---.-</span>
                    </button>
                    <button class="btn memory" onmousedown="startMemory(4)" onmouseup="stopMemory()" onmouseleave="stopMemory()">
                        <span class="memory-label">M4</span>
                        <span class="memory-freq" id="mem4freq">---.-</span>
                    </button>
                    <button class="btn memory" onmousedown="startMemory(5)" onmouseup="stopMemory()" onmouseleave="stopMemory()">
                        <span class="memory-label">M5</span>
                        <span class="memory-freq" id="mem5freq">---.-</span>
                    </button>
                    <button class="btn memory" onmousedown="startMemory(6)" onmouseup="stopMemory()" onmouseleave="stopMemory()">
                        <span class="memory-label">M6</span>
                        <span class="memory-freq" id="mem6freq">---.-</span>
                    </button>
                </div>
                <div class="info">Short press: Recall | Long press: Store current frequency</div>
            </div>
        </div>
    </div>

    <script>
        let ws;
        let stepInterval = null;
        let stepTimeout = null;
        let memoryTimeout = null;
        let currentMemorySlot = 0;
        
        // Memory frequencies storage (index 0 unused, 1-6 for M1-M6)
        let memoryFreqs = ['', '', '', '', '', '', ''];

        function initWebSocket() {
            ws = new WebSocket('ws://' + window.location.hostname + ':81');
            
            ws.onopen = function(event) {
                console.log('WebSocket connected');
                // Request initial status immediately after connection
                setTimeout(() => {
                    sendCommand('getStatus');
                }, 100);
            };
            
            ws.onmessage = function(event) {
                const data = JSON.parse(event.data);
                updateStatus(data);
            };
            
            ws.onclose = function(event) {
                console.log('WebSocket disconnected');
                setTimeout(initWebSocket, 3000);
            };
            
            ws.onerror = function(error) {
                console.log('WebSocket error:', error);
            };
        }

        function updateStatus(data) {
            document.getElementById('frequency').textContent = data.frequency + ' MHz';
            // Convert internal volume (0-15) to display volume (0-100)
            const displayVolume = Math.round((data.volume / 15) * 100);
            document.getElementById('volume').textContent = displayVolume;
            document.getElementById('rssi').textContent = data.rssi;
            document.getElementById('volumeSlider').value = displayVolume;
            
            // Update memory frequencies if provided
            if (data.memories) {
                for (let i = 1; i <= 6; i++) {
                    if (data.memories[i-1] && data.memories[i-1] !== "---.-") {
                        memoryFreqs[i] = data.memories[i-1];
                        document.getElementById(`mem${i}freq`).textContent = data.memories[i-1];
                    }
                }
            }
            
            const muteBtn = document.getElementById('muteBtn');
            const muteStatus = document.getElementById('muteStatus');
            if (data.mute) {
                muteBtn.style.backgroundColor = '#d32f2f';
                muteBtn.textContent = 'UNMUTE';
                muteStatus.textContent = 'MUTED';
                muteStatus.className = 'mute-status muted';
            } else {
                muteBtn.style.backgroundColor = '#f44336';
                muteBtn.textContent = 'MUTE';
                muteStatus.textContent = 'NORMAL';
                muteStatus.className = 'mute-status';
            }
        }

        function sendCommand(command, params = {}) {
            if (ws && ws.readyState === WebSocket.OPEN) {
                const message = { command, ...params };
                ws.send(JSON.stringify(message));
            }
        }

        function startSeek(direction) {
            sendCommand(direction);
        }

        function startStep(direction) {
            // Start immediate step
            sendCommand(direction);
            
            // Set up continuous stepping
            stepInterval = setInterval(() => {
                sendCommand(direction);
            }, 200); // Step every 200ms
            
            // After 5 seconds, switch to fast stepping (1MHz)
            stepTimeout = setTimeout(() => {
                if (stepInterval) {
                    clearInterval(stepInterval);
                    stepInterval = setInterval(() => {
                        // Send 10 steps at once for 1MHz (10 * 0.1MHz = 1MHz)
                        for (let i = 0; i < 10; i++) {
                            sendCommand(direction);
                        }
                    }, 200);
                }
            }, 5000);
        }

        function stopStep() {
            if (stepInterval) {
                clearInterval(stepInterval);
                stepInterval = null;
            }
            if (stepTimeout) {
                clearTimeout(stepTimeout);
                stepTimeout = null;
            }
        }

        function stopAction() {
            // For seek buttons - no special action needed
        }

        function startMemory(slot) {
            currentMemorySlot = slot;
            memoryTimeout = setTimeout(() => {
                // Long press - store current frequency
                const btn = document.querySelector(`.btn.memory:nth-child(${slot})`);
                btn.classList.add('storing');
                
                // Store current frequency in memory array
                const currentFreq = document.getElementById('frequency').textContent.replace(' MHz', '');
                memoryFreqs[slot] = currentFreq;
                document.getElementById(`mem${slot}freq`).textContent = currentFreq;
                
                sendCommand('storeMemory', { slot: slot });
                console.log('Storing to memory slot', slot);
                
                // Remove blue color after 2 seconds
                setTimeout(() => {
                    btn.classList.remove('storing');
                }, 2000);
            }, 1000); // 1 second for long press
        }

        function stopMemory() {
            if (memoryTimeout) {
                clearTimeout(memoryTimeout);
                // Short press - recall memory
                sendCommand('recallMemory', { slot: currentMemorySlot });
                console.log('Recalling memory slot', currentMemorySlot);
                memoryTimeout = null;
            }
        }

        function setVolume(displayVolume) {
            // Convert display volume (0-100) to internal volume (0-15)
            const internalVolume = Math.round((displayVolume / 100) * 15);
            sendCommand('setVolume', { volume: internalVolume });
        }

        // Initialize WebSocket connection
        initWebSocket();
        
        // Fallback: Request status after 2 seconds if still showing dashes
        setTimeout(() => {
            const freq = document.getElementById('frequency').textContent;
            if (freq.includes('---')) {
                console.log('Requesting status update...');
                sendCommand('getStatus');
            }
        }, 2000);
    </script>
</body>
</html>
)rawliteral";
    return html;
}

/**
 * @brief Get web page content
 */
String getWebPage() {
    return generateHTML();
}

/**
 * @brief Initialize and start the web server
 */
bool initWebServer(const char* ssid, const char* password) {
    Serial.println("Starting WiFi connection...");
    
    // Connect to WiFi
    WiFi.mode(WIFI_STA);
    WiFi.begin(ssid, password);
    
    int attempts = 0;
    while (WiFi.status() != WL_CONNECTED && attempts < 30) {
        delay(1000);
        Serial.print(".");
        attempts++;
    }
    
    if (WiFi.status() != WL_CONNECTED) {
        Serial.println("\nFailed to connect to WiFi");
        wifiConnected = false;
        return false;
    }
    
    wifiConnected = true;
    Serial.println("\nWiFi connected!");
    Serial.print("IP address: ");
    Serial.println(WiFi.localIP());
    
    // Start HTTP server
    server.begin();
    Serial.println("HTTP server started on port 80");
    
    // Start WebSocket server
    webSocket.begin();
    webSocket.onEvent(webSocketEvent);
    Serial.println("WebSocket server started on port 81");
    
    return true;
}

/**
 * @brief Handle web server requests
 */
void handleWebServer() {
    // Handle WebSocket events
    webSocket.loop();
    
    // Handle HTTP requests
    WiFiClient client = server.available();
    if (client) {
        Serial.println("New HTTP client connected");
        
        String currentLine = "";
        bool isGetRequest = false;
        
        while (client.connected()) {
            if (client.available()) {
                char c = client.read();
                if (c == '\n') {
                    if (currentLine.length() == 0) {
                        // End of HTTP request headers
                        if (isGetRequest) {
                            // Send HTTP response
                            client.println("HTTP/1.1 200 OK");
                            client.println("Content-type:text/html");
                            client.println("Connection: close");
                            client.println();
                            
                            // Send HTML page
                            client.print(getWebPage());
                        }
                        break;
                    } else {
                        if (currentLine.startsWith("GET /")) {
                            isGetRequest = true;
                        }
                        currentLine = "";
                    }
                } else if (c != '\r') {
                    currentLine += c;
                }
            }
        }
        
        client.stop();
        Serial.println("HTTP client disconnected");
    }
}

/**
 * @brief Get WiFi connection status
 */
bool isWiFiConnected() {
    return wifiConnected && (WiFi.status() == WL_CONNECTED);
}

/**
 * @brief Get local IP address
 */
String getLocalIP() {
    if (isWiFiConnected()) {
        return WiFi.localIP().toString();
    }
    return "Not connected";
}

/**
 * @brief Broadcast radio status to all WebSocket clients
 */
void broadcastRadioStatus() {
    if (!isWiFiConnected()) return;
    
    DynamicJsonDocument doc(1024);
    
    // Get current radio status
    if (cb_getFreq) {
        uint16_t freq = cb_getFreq();
        doc["frequency"] = String(freq / 100.0, 1);
    }
    
    if (cb_getVol) {
        doc["volume"] = cb_getVol();
    }
    
    if (cb_getRssi) {
        doc["rssi"] = cb_getRssi();
    }
    
    doc["mute"] = muteState;
    
    // Add memory frequencies
    JsonArray memories = doc.createNestedArray("memories");
    for (int i = 1; i <= 6; i++) {
        if (cb_getMemoryFreq) {
            uint16_t memFreq = cb_getMemoryFreq(i);
            if (memFreq > 0) {
                memories.add(String(memFreq / 100.0, 1));
            } else {
                memories.add("---.-");
            }
        } else {
            memories.add("---.-");
        }
    }
    
    String jsonString;
    serializeJson(doc, jsonString);
    
    // Send to all connected WebSocket clients
    webSocket.broadcastTXT(jsonString);
}

/**
 * @brief Send status to specific WebSocket client
 */
void sendStatusToClient(uint8_t clientId) {
    if (!isWiFiConnected()) return;
    
    DynamicJsonDocument doc(1024);
    
    // Get current radio status
    if (cb_getFreq) {
        uint16_t freq = cb_getFreq();
        doc["frequency"] = String(freq / 100.0, 1);
    }
    
    if (cb_getVol) {
        doc["volume"] = cb_getVol();
    }
    
    if (cb_getRssi) {
        doc["rssi"] = cb_getRssi();
    }
    
    doc["mute"] = muteState;
    
    // Add memory frequencies
    JsonArray memories = doc.createNestedArray("memories");
    for (int i = 1; i <= 6; i++) {
        if (cb_getMemoryFreq) {
            uint16_t memFreq = cb_getMemoryFreq(i);
            if (memFreq > 0) {
                memories.add(String(memFreq / 100.0, 1));
            } else {
                memories.add("---.-");
            }
        } else {
            memories.add("---.-");
        }
    }
    
    String jsonString;
    serializeJson(doc, jsonString);
    
    // Send to specific client
    webSocket.sendTXT(clientId, jsonString);
}

/**
 * @brief Set radio callback functions
 */
void setRadioCallbacks(
    void (*seekUp)(),
    void (*seekDown)(),
    void (*volumeUp)(),
    void (*volumeDown)(),
    void (*setFreq)(uint16_t),
    uint16_t (*getFreq)(),
    uint8_t (*getVol)(),
    uint8_t (*getRssi)(),
    void (*setMute)(bool)
) {
    cb_seekUp = seekUp;
    cb_seekDown = seekDown;
    cb_volumeUp = volumeUp;
    cb_volumeDown = volumeDown;
    cb_setFreq = setFreq;
    cb_getFreq = getFreq;
    cb_getVol = getVol;
    cb_getRssi = getRssi;
    cb_setMute = setMute;
}

/**
 * @brief Set step callback functions
 */
void setStepCallbacks(
    void (*stepUp)(),
    void (*stepDown)()
) {
    cb_stepUp = stepUp;
    cb_stepDown = stepDown;
}

/**
 * @brief Set additional radio callbacks
 */
void setAdditionalRadioCallbacks(
    void (*setVolume)(uint8_t),
    void (*recallMemory)(uint8_t),
    void (*storeMemory)(uint8_t)
) {
    cb_setVolume = setVolume;
    cb_recallMemory = recallMemory;
    cb_storeMemory = storeMemory;
}

/**
 * @brief Set memory callback function
 */
void setMemoryCallback(
    uint16_t (*getMemoryFreq)(uint8_t)
) {
    cb_getMemoryFreq = getMemoryFreq;
}
