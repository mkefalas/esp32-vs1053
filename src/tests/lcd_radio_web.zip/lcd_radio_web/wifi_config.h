/**
 * @file wifi_config.h
 * @brief WiFi configuration for radio web server
 * @details The ESP32 will connect to your existing WiFi network as a client
 * 
 * HOW TO USE:
 * 1. Set your WiFi network name and password below
 * 2. Upload the code to your ESP32
 * 3. Check the Serial Monitor for the IP address assigned to ESP32
 * 4. Open a web browser and go to that IP address
 * 5. Control your radio from the web interface!
 * 
 * Change the network name and password below to match your WiFi.
 */

#ifndef WIFI_CONFIG_H
#define WIFI_CONFIG_H

// Access Point mode settings - Not used in client mode
#define AP_MODE_ENABLED false
#define AP_SSID "Digimations"          // Not used when AP_MODE_ENABLED is false
#define AP_PASSWORD "Radio12345"       // Not used when AP_MODE_ENABLED is false

// Web server settings  
#define WEB_SERVER_PORT 80

// Station mode settings (for connecting to existing WiFi)
#define WIFI_SSID "MKEF"        // CHANGE THIS to your WiFi network name
#define WIFI_PASSWORD "1234567cbe"     // CHANGE THIS to your WiFi password

#endif
